<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Password Generator | Brave Coder</title>
</head>
<body>
	<div class="wrapper">
		<div class="title">Simple Password Generator</div>
		<div class="inputBox">
			<input type="text" id="password">
		</div>
		<div class="buttons">
			<button id="generate">Generate</button>
			<button id="clear">Clear</button>
		</div>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

	<script>
		$(document).ready(function(){
			var input = $("#password");
			$("#generate").on("click", function(){
				$.ajax({
					url: 'process.php',
					type: 'post',
					success: function(result){
						input.val(result);
					}
				});
			});

			$("#clear").on("click", function(){
				input.val('');
			});
		});
	</script>
</body>
</html>