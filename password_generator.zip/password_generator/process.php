<?php
	$str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()_+|]}[{?<>*";
	$password = str_shuffle($str);
	$final_password = substr($password, 0, 16);
	echo $final_password;
?>